import os
import re
import shutil
import pandas as pd
from flask import Flask, render_template, request, url_for
from icrawler.builtin import GoogleImageCrawler
from PIL import Image, ImageOps

app = Flask(__name__)

# Path to CSV file containing product details.
CSV_FILE = "products.csv"
products_df = pd.read_csv(CSV_FILE)

# Define 10 evaluation outcomes with finer score ranges.
# Total score can be 0-32 (8 questions × max 4).
evaluations = [
    {"range": range(0, 4),
     "title": "Minimal Impact",
     "description": "Your routine is hardly disrupted.",
     "product": "Liril Refreshing Soap"},
    {"range": range(4, 7),
     "title": "Slightly Affected",
     "description": "The issue barely causes inconvenience.",
     "product": "Hamam Soft Soap"},
    {"range": range(7, 10),
     "title": "Mildly Affected",
     "description": "You experience minor daily clutter.",
     "product": "Lifebuoy Total 10 Soap"},
    {"range": range(10, 13),
     "title": "Noticeably Affected",
     "description": "The storage issue slightly disrupts your routine.",
     "product": "Dove Deeply Nourishing Body Wash"},
    {"range": range(13, 16),
     "title": "Moderately Affected",
     "description": "There’s clear inconvenience; a better solution is needed.",
     "product": "Nivea Fresh Active Body Wash"},
    {"range": range(16, 19),
     "title": "Somewhat Disrupted",
     "description": "The storage problem affects you enough to seek change.",
     "product": "Clinic Plus Anti Hair Fall Shampoo"},
    {"range": range(19, 22),
     "title": "Affected",
     "description": "You face notable disruptions in your routine.",
     "product": "Sunsilk Smooth & Manageable Shampoo"},
    {"range": range(22, 25),
     "title": "Heavily Affected",
     "description": "Daily clutter is a real headache.",
     "product": "Dove Hair Fall Rescue Shampoo"},
    {"range": range(25, 29),
     "title": "Severely Affected",
     "description": "The problem has a significant negative impact.",
     "product": "Pantene Pro-V Total Damage Shampoo"},
    {"range": range(29, 33),
     "title": "In Crisis",
     "description": "Your bathroom is in chaos – an immediate solution is needed!",
     "product": "Tresemme Moisture Rich Shampoo"}
]

def extract_numeric(s):
    """Extract the first integer from a string, or return 0 if none found."""
    match = re.search(r"(\d+)", s)
    return int(match.group(1)) if match else 0

def normalize_filename(s):
    """Normalize a string for use as a filename (allow only alphanumeric, dot, underscore, and hyphen)."""
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in s)

def lookup_product_entry(product_query):
    """
    Filter the CSV for rows where 'Product Name' contains the product_query string.
    Then select the row with the largest numeric value in the 'Size' column.
    """
    filtered = products_df[products_df["Product Name"].str.contains(product_query, case=False, na=False)]
    if not filtered.empty:
        filtered = filtered.copy()
        filtered["numeric_size"] = filtered["Size"].apply(extract_numeric)
        best_row = filtered.sort_values("numeric_size", ascending=False).iloc[0]
        return best_row
    return None

def lookup_product_image(product_query):
    """
    Look up the best matching product entry and then construct an image filename
    based on the product name, size, and packaging.
    """
    entry = lookup_product_entry(product_query)
    if entry is not None:
        product_name = entry["Product Name"]
        size = entry["Size"]
        packaging = entry["Packaging"]
        filename = normalize_filename(f"{product_name}_{size}") + ".jpg"
        return filename
    return "default.jpg"

def get_evaluation(total_score):
    """Return the evaluation dictionary based on the total score."""
    for eval_item in evaluations:
        if total_score in eval_item["range"]:
            return eval_item
    return evaluations[-1]

@app.route("/", methods=["GET", "POST"])
def quiz():
    if request.method == "POST":
        # Get compulsory details.
        name = request.form.get("name")
        roll_number = request.form.get("roll_number")
        email = request.form.get("email")
        graduation_year = request.form.get("graduation_year")
        school = request.form.get("school")
        
        # Retrieve survey answers from 8 questions (each 0 to 4).
        q1 = int(request.form.get("q1", 0))
        q2 = int(request.form.get("q2", 0))
        q3 = int(request.form.get("q3", 0))
        q4 = int(request.form.get("q4", 0))
        q5 = int(request.form.get("q5", 0))
        q6 = int(request.form.get("q6", 0))
        q7 = int(request.form.get("q7", 0))
        q8 = int(request.form.get("q8", 0))
        
        total_score = q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8
        evaluation = get_evaluation(total_score)
        
        # Lookup the full product details.
        entry = lookup_product_entry(evaluation["product"])
        if entry is not None:
            display_product = f"{entry['Product Name']} {entry['Size']} {entry['Packaging']}"
        else:
            display_product = evaluation["product"]
        
        image_filename = lookup_product_image(evaluation["product"])
        
        # Render the result page with the incentive product details and image.
        return render_template("result.html",
                               name=name,
                               roll_number=roll_number,
                               email=email,
                               graduation_year=graduation_year,
                               school=school,
                               evaluation=evaluation,
                               display_product=display_product,
                               image_filename=image_filename)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
