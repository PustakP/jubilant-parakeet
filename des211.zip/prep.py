import os
import shutil
import pandas as pd
from icrawler.builtin import GoogleImageCrawler
from PIL import Image, ImageOps

# Parameters
CSV_FILE = "products.csv"        # Path to your CSV file
OUTPUT_FOLDER = "downloaded_images"
TEMP_FOLDER = "temp_download"
TARGET_SIZE = (500, 500)         # Desired output size (width, height) in pixels

# Create output folder if it doesn't exist
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def normalize_filename(s):
    """Return a normalized filename by allowing only alphanumeric, dot, underscore and hyphen."""
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in s)

# Read the CSV file using pandas
df = pd.read_csv(CSV_FILE)

# Process each product in the CSV
for index, row in df.iterrows():
    # Build the search query using Product Name, Brand, and Packaging
    query = f"{row['Product Name']} {row['Brand']} {row['Packaging']}"
    print(f"Searching image for: {query}")
    
    # Clear temporary download folder
    if os.path.exists(TEMP_FOLDER):
        shutil.rmtree(TEMP_FOLDER)
    os.makedirs(TEMP_FOLDER, exist_ok=True)
    
    # Configure and run the Google image crawler (download only 1 image)
    crawler = GoogleImageCrawler(storage={'root_dir': TEMP_FOLDER})
    crawler.crawl(keyword=query, max_num=1)
    
    # Check for downloaded image files
    downloaded_files = os.listdir(TEMP_FOLDER)
    if downloaded_files:
        img_path = os.path.join(TEMP_FOLDER, downloaded_files[0])
        try:
            with Image.open(img_path) as img:
                # Convert to RGB (in case image is in another mode)
                img = img.convert("RGB")
                # Resize the image while preserving its aspect ratio.
                # This method scales the image to fit within TARGET_SIZE.
                resized_img = ImageOps.contain(img, TARGET_SIZE)
                # Create a new image with white background and target dimensions.
                new_img = Image.new("RGB", TARGET_SIZE, (255, 255, 255))
                # Center the resized image on the white background.
                x = (TARGET_SIZE[0] - resized_img.width) // 2
                y = (TARGET_SIZE[1] - resized_img.height) // 2
                new_img.paste(resized_img, (x, y))
                # Normalize filename (using product name and size for clarity)
                file_name = normalize_filename(f"{row['Product Name']}_{row['Size']}.jpg")
                save_path = os.path.join(OUTPUT_FOLDER, file_name)
                new_img.save(save_path, "JPEG")
                print(f"Saved image for '{query}' as {file_name}")
        except Exception as e:
            print(f"Error processing image for '{query}': {e}")
    else:
        print(f"No image found for '{query}'.")
    
    # Remove temporary folder before next iteration
    shutil.rmtree(TEMP_FOLDER)
